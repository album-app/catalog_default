from io import StringIO

from album.runner.api import setup, get_args

env_file = StringIO("""name: template-python
channels:
  - conda-forge
  - defaults
dependencies:
  - python=3.8
  - napari=0.4.10
  - scikit-image=0.18.3

""")


def run():
    import napari
    from skimage.io import imread

    print("Napari template :: run")
    img = imread(get_args().input_image_path)
    napari.view_image(img, rgb=False, name="Input image")
    napari.run()


setup(
    group="album",
    name="template-napari",
    version="0.1.0-SNAPSHOT",
    title="Napari template",
    description="An album solution template for running Napari.",
    authors=["Your name"],
    cite=[{
        "text": "napari contributors (2019). napari: a multi-dimensional image viewer for python.",
        "doi": "10.5281/zenodo.3555620",
        "url": "https://github.com/napari/napari"
    }, {
        "text": "Your citation text",
        "doi": "your citation doi",
        "url": "your citation url"
    }],
    tags=["template", "napari"],
    license="UNLICENSE",
    documentation=["documentation.md"],
    covers=[{
        "description": "Dummy cover image.",
        "source": "cover.png"
    }],
    album_api_version="0.2.1",
    args=[{
        "name": "input_image_path",
        "type": "file",
        "description": "The image about to be displayed in Napari.",
        "required": True
    }],
    run=run,
    dependencies={'environment_file': env_file}
)
