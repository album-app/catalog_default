from io import StringIO

from album.runner import setup
from album.runner.api import get_args

env_file = StringIO("""name: template-python
channels:
  - conda-forge
  - defaults
dependencies:
  - python=3.8
  - napari[all]=0.4.10

""")


def install():
    print("Napari template :: install")


def run():
    import napari
    from skimage import data

    print("Napari template :: run")

    args = get_args()

    napari.view_image(data.astronaut(), rgb=True, name="Hi " + str(args.name))
    napari.run()


def close():
    print("Napari template :: close")


setup(
    group="album",
    name="template-napari",
    version="0.1.0-SNAPSHOT",
    title="Python template",
    description="An album solution template for running Napari.",
    authors=["Your name"],
    cite=[{
        "text": "Your first citation text",
        "doi": "your first citation doi"
    }, {
        "text": "Your second citation text",
        "doi": "your second citation doi"
    }],
    git_repo="https://gitlab.com/album-app/catalogs/default",
    tags=["template", "napari"],
    license="UNLICENSE",
    documentation=["documentation.md"],
    covers=[{
        "description": "Dummy cover image.",
        "source": "cover.png"
    }],
    album_version="0.1.0",
    album_api_version="0.1.0",
    timestamp="",
    args=[{
        "name": "name",
        "type": "string",
        "default": "Bugs Bunny",
        "description": "How to you want to be addressed?"
    }],
    install=install,
    run=run,
    close=close,
    dependencies={'environment_file': env_file}
)
