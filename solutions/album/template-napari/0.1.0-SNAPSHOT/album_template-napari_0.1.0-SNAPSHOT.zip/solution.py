from album_runner import setup

from io import StringIO

env_file = StringIO("""name: template-python
channels:
  - conda-forge
  - defaults
dependencies:
  - python=3.8
  - napari[all]=0.4.10

""")

global args


def init():
    global args
    print("Napari template :: init")
    args = {}


def install():
    print("Napari template :: install")


def run():
    global args
    import napari
    from skimage import data
    import time
    print("Napari template :: run")
    napari.view_image(data.astronaut(), rgb=True, name="Hi " + str(args["name"]))
    napari.run()


def close():
    print("Napari template :: close")


setup(
    group="album",
    name="template-napari",
    version="0.1.0-SNAPSHOT",
    format_version="0.3.0",
    title="Python template",
    description="An album solution template for running Napari.",
    authors=["Your name"],
    cite=[{
        "text": "Your first citation text",
        "doi": "your first citation doi"
    }, {
        "text": "Your second citation text",
        "doi": "your second citation doi"
    }],
    git_repo="https://gitlab.com/album-app/catalogs/default",
    tags=["template", "napari"],
    license="UNLICENSE",
    documentation="",
    covers=[{
        "description": "Dummy cover image.",
        "source": "cover.png"
    }],
    min_album_version="0.1.0",
    tested_album_version="0.1.0",
    timestamp="",
    args=[{
        "name": "name",
        "type": "string",
        "default": "Bugs Bunny",
        "action": lambda value: args.update({"name": value}),
        "description": "How to you want to be addressed?"
    }],
    install=install,
    init=init,
    run=run,
    close=close,
    dependencies={'environment_file': env_file}
)
