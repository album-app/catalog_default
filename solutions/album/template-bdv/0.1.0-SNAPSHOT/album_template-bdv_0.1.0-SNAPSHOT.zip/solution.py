from album_runner import setup

from io import StringIO

env_file = StringIO("""name: template-bdv
channels:
  - conda-forge
  - defaults
dependencies:
  - python=3.6
  - scyjava=1.1.0
  - openjdk=11.0.9.1
""")

global args


def init():
    global args
    from scyjava import config, jimport
    print("BDV template :: init")
    config.add_repositories({'scijava.public': 'https://maven.scijava.org/content/groups/public'})
    config.add_endpoints('sc.fiji:bigdataviewer-vistools:1.0.0-beta-28')
    HashMap = jimport("java.util.HashMap")
    args = HashMap()


def install():
    print("BDV template :: install")


def run():
    global args
    from scyjava import jimport
    print("BDV template :: run")
    Random = jimport("java.util.Random")
    ArrayImgs = jimport("net.imglib2.img.array.ArrayImgs")
    BdvFunctions = jimport("bdv.util.BdvFunctions")
    Bdv = jimport("bdv.util.Bdv")
    random = Random()
    img = ArrayImgs.argbs(100, 100, 100)
    for t in img:
        t.set(random.nextInt())
    BdvFunctions.show(img, args.get("name"), Bdv.options().is2D())


def close():
    print("BDV template :: close")


setup(
    group="album",
    name="template-bdv",
    version="0.1.0-SNAPSHOT",
    format_version="0.3.0",
    title="BigDataViewer template",
    description="An album solution template displaying an image with random values in BigDataViewer.",
    authors=["Your name"],
    cite=[{
        "text": "Pietzsch, T., Saalfeld, S., Preibisch, S., & Tomancak, P. (2015). BigDataViewer: visualization and processing for large image data sets. Nature Methods, 12(6), 481–483.",
        "doi": "10.1038/nmeth.3392"
    }, {
        "text": "Your citation text",
        "doi": "your citation doi"
    }],
    git_repo="https://gitlab.com/album-app/catalogs/default",
    tags=["template", "java", "bdv", "bigdataviewer"],
    license="UNLICENSE",
    documentation="",
    covers=[{
        "description": "Dummy cover image.",
        "source": "cover.png"
    }],
    min_album_version="0.1.0",
    tested_album_version="0.1.0",
    timestamp="",
    args=[{
        "name": "name",
        "type": "string",
        "default": "random",
        "action": lambda value: args.put("name", value),
        "description": "A name for the image to be generated"
    }],
    install=install,
    init=init,
    run=run,
    close=close,
    dependencies={'environment_file': env_file}
)
