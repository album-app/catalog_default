from io import StringIO

from album.runner import setup

env_file = StringIO("""name: template-python
channels:
  - conda-forge
  - defaults
dependencies:
  - python=3.6
""")


setup(
    group="album",
    name="template-minimal",
    version="0.1.0-SNAPSHOT",
    album_api_version="0.1.1"
    # dependencies={'environment_file': env_file}
)
