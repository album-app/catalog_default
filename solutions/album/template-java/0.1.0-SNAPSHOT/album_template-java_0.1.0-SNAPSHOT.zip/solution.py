from io import StringIO

from album.runner import setup
from album.runner.api import get_args

env_file = StringIO("""name: template-java
channels:
  - conda-forge
  - defaults
dependencies:
  - python=3.6
  - scyjava=1.1.0
  - openjdk=11.0.9.1
""")


def install():
    print("Java template :: install")


def run():
    print("Java template :: run")

    args = get_args()

    print("Hi " + str(args.name) + ", nice to meet you!")


def close():
    print("Java template :: close")


setup(
    group="album",
    name="template-java",
    version="0.1.0-SNAPSHOT",
    title="Java template",
    description="An album solution template for running Java code.",
    authors=["Your name"],
    cite=[{
        "text": "Your first citation text",
        "doi": "your first citation doi",
        "url": "your first citation url"
    }, {
        "text": "Your second citation text",
        "doi": "your second citation doi",
        "url": "your second citation url"
    }],
    tags=["template", "python"],
    license="UNLICENSE",
    documentation=["documentation.md"],
    covers=[{
        "description": "Dummy cover image.",
        "source": "cover.png"
    }],
    album_api_version="0.1.1",
    args=[{
        "name": "name",
        "type": "string",
        "default": "Bugs Bunny",
        "description": "How to you want to be addressed?"
    }],
    install=install,
    run=run,
    close=close,
    dependencies={'environment_file': env_file}
)
