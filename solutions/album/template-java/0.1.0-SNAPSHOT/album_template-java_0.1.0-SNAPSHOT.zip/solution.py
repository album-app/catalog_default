from album_runner import setup

from io import StringIO

env_file = StringIO("""name: template-java
channels:
  - conda-forge
  - defaults
dependencies:
  - python=3.6
  - scyjava
  - openjdk=8.0.152
""")

global args


def init():
    global args
    from scyjava import jimport
    print("Java template :: init")
    HashMap = jimport("java.util.HashMap")
    args = HashMap()


def install():
    print("Java template :: install")


def run():
    global args
    print("Java template :: run")
    print("Hi " + str(args.get("name")) + ", nice to meet you!")


def close():
    print("Java template :: close")


setup(
    group="album",
    name="template-java",
    version="0.1.0-SNAPSHOT",
    format_version="0.3.0",
    title="Java template",
    description="An album solution template for running Java code.",
    authors=["Deborah Schmidt"],
    cite=[{
        "text": "Your first citation text here",
        "doi": "your first citation doi here"
    }, {
        "text": "Your second citation text here",
        "doi": "your second citation doi here"
    }],
    git_repo="https://gitlab.com/album-app/catalogs/default",
    tags=["template", "python"],
    license="UNLICENSE",
    documentation="",
    covers=[{
        "description": "Dummy cover image.",
        "source": "cover.png"
    }],
    min_album_version="0.1.0",
    tested_album_version="0.1.0",
    timestamp="",
    args=[{
        "name": "name",
        "type": "string",
        "default": "Bugs Bunny",
        "action": lambda value: args.put("name", value),
        "description": "How to you want to be addressed?"
    }],
    install=install,
    init=init,
    run=run,
    close=close,
    dependencies={'environment_file': env_file}
)
