from io import StringIO

from album.runner.api import setup, get_args

env_file = StringIO("""name: template-python
channels:
  - conda-forge
  - defaults
dependencies:
  - python=3.6
""")


def install():
    print("Python template :: install")


def run():
    print("Python template :: run")

    args = get_args()

    print("Hi " + str(args.name) + ", nice to meet you!")


def close():
    print("Python template :: close")


setup(
    group="album",
    name="template-python",
    version="0.1.0-SNAPSHOT",
    title="Python template",
    description="An album solution template for running Python code.",
    authors=["Your name"],
    cite=[{
        "text": "Your first citation text",
        "doi": "your first citation doi",
        "url": "your first citation url"
    }, {
        "text": "Your second citation text",
        "doi": "your second citation doi",
        "url": "your second citation url"
    }],
    tags=["template", "java"],
    license="UNLICENSE",
    documentation=["documentation.md"],
    covers=[{
        "description": "Dummy cover image.",
        "source": "cover.png"
    }],
    album_api_version="0.1.1",
    args=[{
        "name": "name",
        "type": "string",
        "default": "Bugs Bunny",
        "description": "How to you want to be addressed?"
    }],
    install=install,
    run=run,
    close=close,
    dependencies={'environment_file': env_file}
)
