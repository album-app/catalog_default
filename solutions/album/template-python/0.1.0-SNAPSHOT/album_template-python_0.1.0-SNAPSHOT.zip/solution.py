from album_runner import setup

from io import StringIO

env_file = StringIO("""name: template-python
channels:
  - conda-forge
  - defaults
dependencies:
  - python=3.6
""")

global args


def init():
    global args
    print("Python template :: init")
    args = {}


def install():
    print("Python template :: install")


def run():
    global args
    print("Python template :: run")
    print("Hi " + str(args["name"]) + ", nice to meet you!")


def close():
    print("Python template :: close")


setup(
    group="album",
    name="template-python",
    version="0.1.0-SNAPSHOT",
    format_version="0.3.0",
    title="Python template",
    description="An album solution template for running Python code.",
    authors=["Your name"],
    cite=[{
        "text": "Your first citation text",
        "doi": "your first citation doi"
    }, {
        "text": "Your second citation text",
        "doi": "your second citation doi"
    }],
    git_repo="https://gitlab.com/album-app/catalogs/default",
    tags=["template", "java"],
    license="UNLICENSE",
    documentation="",
    covers=[{
        "description": "Dummy cover image.",
        "source": "cover.png"
    }],
    min_album_version="0.1.0",
    tested_album_version="0.1.0",
    timestamp="",
    args=[{
        "name": "name",
        "type": "string",
        "default": "Bugs Bunny",
        "action": lambda value: args.update({"name": value}),
        "description": "How to you want to be addressed?"
    }],
    install=install,
    init=init,
    run=run,
    close=close,
    dependencies={'environment_file': env_file}
)
