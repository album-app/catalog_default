from album_runner import setup

from io import StringIO

env_file = StringIO("""name: template-imagej2
channels:
  - conda-forge
  - defaults
dependencies:
  - python=3.6
  - scyjava=1.1.0
  - openjdk=11.0.9.1
""")

global args


def init():
    global args
    from scyjava import config, jimport
    print("SciJava template :: init")
    config.add_repositories({'scijava.public': 'https://maven.scijava.org/content/groups/public'})
    config.add_endpoints('org.scijava:scijava-ui-swing:0.13.2')
    HashMap = jimport("java.util.HashMap")
    args = HashMap()


def install():
    print("SciJava template :: install")


def run():
    global args
    from scyjava import jimport
    print("SciJava template :: run")
    SciJava = jimport("org.scijava.SciJava")
    sj = SciJava()
    sj.ui().show(args.get("name"))


def close():
    print("SciJava template :: close")


setup(
    group="album",
    name="template-scijava",
    version="0.1.0-SNAPSHOT",
    format_version="0.3.0",
    title="SciJava template",
    description="An album solution template displaying a text in SciJava.",
    authors=["Your name"],
    cite=[{
        "text": "Rueden, C., Schindelin, J., Hiner, M. & Eliceiri, K. (2021). SciJava Common [Software]. https://scijava.org/.",
    }, {
        "text": "Your citation text",
        "doi": "your citation doi"
    }],
    git_repo="https://gitlab.com/album-app/catalogs/default",
    tags=["template", "java", "scijava"],
    license="UNLICENSE",
    documentation="",
    covers=[{
        "description": "Dummy cover image.",
        "source": "cover.png"
    }],
    min_album_version="0.1.0",
    tested_album_version="0.1.0",
    timestamp="",
    args=[{
        "name": "name",
        "type": "string",
        "default": "Bugs Bunny",
        "action": lambda value: args.put("name", value),
        "description": "How would you like to be addressed?"
    }],
    install=install,
    init=init,
    run=run,
    close=close,
    dependencies={'environment_file': env_file}
)
