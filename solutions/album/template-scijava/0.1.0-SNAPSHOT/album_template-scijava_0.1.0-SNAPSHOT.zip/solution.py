from io import StringIO

from album.runner.api import setup, get_args

env_file = StringIO("""name: template-imagej2
channels:
  - conda-forge
  - defaults
dependencies:
  - python=3.6
  - scyjava=1.1.0
  - openjdk=11.0.9.1
""")


def install():
    print("SciJava template :: install")


def run():
    from scyjava import config, jimport
    print("SciJava template :: run")
    config.add_repositories({'scijava.public': 'https://maven.scijava.org/content/groups/public'})
    config.add_endpoints('org.scijava:scijava-ui-swing:0.13.2')

    args = get_args()

    SciJava = jimport("org.scijava.SciJava")
    sj = SciJava()
    sj.ui().show(args.name)


def close():
    print("SciJava template :: close")


setup(
    group="album",
    name="template-scijava",
    version="0.1.0-SNAPSHOT",
    title="SciJava template",
    description="An album solution template displaying a text in SciJava.",
    authors=["Your name"],
    cite=[{
        "text": "Rueden, C., Schindelin, J., Hiner, M. & Eliceiri, K. (2021). SciJava Common [Software].",
        "url": "https://scijava.org/"
    }, {
        "text": "Your citation text",
        "doi": "your citation doi",
        "url": "your citation url"
    }],
    tags=["template", "java", "scijava"],
    license="UNLICENSE",
    documentation=["documentation.md"],
    covers=[{
        "description": "Dummy cover image.",
        "source": "cover.png"
    }],
    album_api_version="0.1.1",
    args=[{
        "name": "name",
        "type": "string",
        "default": "Bugs Bunny",
        "description": "How would you like to be addressed?"
    }],
    install=install,
    run=run,
    close=close,
    dependencies={'environment_file': env_file}
)
