from io import StringIO

from album.runner import setup
from album.runner.api import get_args

env_file = StringIO("""name: template-imagej2
channels:
  - conda-forge
  - defaults
dependencies:
  - python=3.6
  - scyjava=1.1.0
  - openjdk=11.0.9.1
""")


def install():
    print("ImageJ2 template :: install")


def run():
    from scyjava import config, jimport
    print("ImageJ2 template :: run")
    config.add_repositories({'scijava.public': 'https://maven.scijava.org/content/groups/public'})
    config.add_endpoints('net.imagej:imagej:2.2.0')

    ImageJ = jimport("net.imagej.ImageJ")
    Random = jimport("java.util.Random")
    ArrayImgs = jimport("net.imglib2.img.array.ArrayImgs")
    random = Random()
    img = ArrayImgs.argbs(100, 100, 100)
    for t in img:
        t.set(random.nextInt())

    args = get_args()

    ij = ImageJ()
    ij.ui().show(args.name, img)


def close():
    print("ImageJ2 template :: close")


setup(
    group="album",
    name="template-imagej2",
    version="0.1.0-SNAPSHOT",
    title="ImageJ2 template",
    description="An album solution template displaying an image with random values in ImageJ2.",
    authors=["Your name"],
    cite=[{
        "text": "Rueden, C. T., Schindelin, J., Hiner, M. C., DeZonia, B. E., Walter, A. E., Arena, E. T., & Eliceiri, K. W. (2017). ImageJ2: ImageJ for the next generation of scientific image data. BMC Bioinformatics, 18(1).",
        "doi": "10.1186/s12859-017-1934-z"
    }, {
        "text": "Your citation text",
        "doi": "your citation doi"
    }],
    git_repo="https://gitlab.com/album-app/catalogs/default",
    tags=["template", "java", "imagej2", "scijava"],
    license="UNLICENSE",
    documentation=["documentation.md"],
    covers=[{
        "description": "Dummy cover image.",
        "source": "cover.png"
    }],
    album_version="0.1.0",
    album_api_version="0.1.0",
    timestamp="",
    args=[{
        "name": "name",
        "type": "string",
        "default": "random",
        "description": "A name for the image to be generated"
    }],
    install=install,
    run=run,
    close=close,
    dependencies={'environment_file': env_file}
)
