from io import StringIO

from album.runner.api import setup, get_args, get_cache_path

env_file = StringIO("""name: template-imagej2
channels:
  - conda-forge
  - defaults
dependencies:
  - python=3.6
  - scyjava=1.1.0
  - openjdk=11.0.9.1
""")


def init():
    from scyjava import config
    config.add_repositories({'scijava.public': 'https://maven.scijava.org/content/groups/public'})
    config.add_endpoints('net.imagej:imagej:2.2.0')


def install():
    init()


def run():
    from scyjava import jimport, to_java
    from pathlib import Path

    init()

    ImageJ = jimport("net.imagej.ImageJ")
    FloatType = jimport("net.imglib2.type.numeric.real.FloatType")
    DatasetIOService = jimport("io.scif.services.DatasetIOService")

    ij = ImageJ()

    img = ij.op().run("create.img", to_java([100, 100, 100]), FloatType())

    Random = jimport("java.util.Random")
    random = Random()
    for t in img:
        t.set(random.nextInt())

    img = ij.op().filter().dog(img, 5.0, 2.0)

    Path(get_args().output_image_path).parent.mkdir(parents=True, exist_ok=True)

    ij.get(DatasetIOService).save(ij.dataset().create(img), get_args().output_image_path)

    ij.dispose()


def prepare_test():
    return {
        "--output_image_path": str(get_cache_path().joinpath("output.tif"))
    }


def test():
    assert get_cache_path().joinpath("output.tif").exists()


setup(
    group="album",
    name="template-imagej2",
    version="0.1.0-SNAPSHOT",
    title="ImageJ2 template",
    description="An album solution template generating an imglib2 image with random values in ImageJ2.",
    authors=["Your name"],
    cite=[{
        "text": "Rueden, C. T., Schindelin, J., Hiner, M. C., DeZonia, B. E., Walter, A. E., Arena, E. T., & Eliceiri, K. W. (2017). ImageJ2: ImageJ for the next generation of scientific image data. BMC Bioinformatics, 18(1).",
        "doi": "10.1186/s12859-017-1934-z",
        "url": "https://imagej.net"
    }, {
        "text": "Your citation text",
        "doi": "your citation doi",
        "url": "your citation url"
    }],
    tags=["template", "java", "imagej2", "scijava"],
    license="UNLICENSE",
    documentation=["documentation.md"],
    covers=[{
        "description": "Dummy cover image.",
        "source": "cover.png"
    }],
    album_api_version="0.2.1",
    args=[{
        "name": "output_image_path",
        "type": "file",
        "description": "The output file name to where a random image is going to be saved."
    }],
    install=install,
    run=run,
    pre_test=prepare_test,
    test=test,
    dependencies={'environment_file': env_file}
)
