from io import StringIO

from album.runner.api import setup, get_args

env_file = StringIO("""name: template-imagej2
channels:
  - conda-forge
  - defaults
dependencies:
  - python=3.6
  - scyjava=1.1.0
  - openjdk=11.0.9.1
""")


def install():
    print("ImageJ template :: install")


def run():
    from scyjava import config, jimport
    print("ImageJ template :: run")

    config.add_repositories({'scijava.public': 'https://maven.scijava.org/content/groups/public'})
    config.add_endpoints('net.imagej:ij:1.53j')

    args = get_args()

    IJ = jimport("ij.IJ")
    imp = IJ.createImage(args.name, "noise", 100, 100, 100)
    imp.show()


def close():
    print("ImageJ template :: close")


setup(
    group="album",
    name="template-imagej",
    version="0.1.0-SNAPSHOT",
    title="ImageJ template",
    description="An album solution template displaying a noisy image in ImageJ.",
    authors=["Your name"],
    cite=[{
        "text": "Schneider, C. A., Rasband, W. S., & Eliceiri, K. W. (2012). NIH Image to ImageJ: 25 years of image analysis. Nature Methods, 9(7), 671–675.",
        "doi": "10.1038/nmeth.2089",
        "url": "https://imagej.nih.gov/ij/"
    }, {
        "text": "Your citation text",
        "doi": "your citation doi",
        "url": "your citation url"
    }],
    tags=["template", "java", "imagej"],
    license="UNLICENSE",
    documentation=["documentation.md"],
    covers=[{
        "description": "Dummy cover image.",
        "source": "cover.png"
    }],
    album_api_version="0.2.1",
    args=[{
        "name": "name",
        "type": "string",
        "default": "random",
        "description": "A name for the image to be generated"
    }],
    install=install,
    run=run,
    close=close,
    dependencies={'environment_file': env_file}
)
