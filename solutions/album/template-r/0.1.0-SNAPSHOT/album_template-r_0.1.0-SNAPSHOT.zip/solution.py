import subprocess

from album_runner import setup

from io import StringIO

env_file = StringIO("""name: template-r
channels:
  - conda-forge
  - defaults
dependencies:
  - python=3.8
  - R

""")

script_file = """
args = commandArgs(trailingOnly=TRUE)
print(paste("Hi ", args[1], ", how are you?"))

"""

global args


def init():
    global args
    print("R template :: init")
    args = {}


def install():
    print("R template :: install")


def run():
    import tempfile
    import subprocess
    global args
    print("R template :: run")
    with tempfile.NamedTemporaryFile(suffix=".r") as tmp:
        tmp.write(str.encode(script_file))
        params = ['Rscript', '--vanilla', tmp.name]
        print(" ".join(params))
        subprocess.run(params)


def close():
    print("R template :: close")


setup(
    group="album",
    name="template-r",
    version="0.1.0-SNAPSHOT",
    format_version="0.3.0",
    title="R template",
    description="An album solution template for running R code.",
    authors=["Deborah Schmidt"],
    cite=[{
        "text": "Your first citation text here",
        "doi": "your first citation doi here"
    }, {
        "text": "Your second citation text here",
        "doi": "your second citation doi here"
    }],
    git_repo="https://gitlab.com/album-app/catalogs/default",
    tags=["template", "R"],
    license="UNLICENSE",
    documentation="",
    covers=[{
        "description": "Dummy cover image.",
        "source": "cover.png"
    }],
    min_album_version="0.1.0",
    tested_album_version="0.1.0",
    timestamp="",
    args=[{
        "name": "name",
        "type": "string",
        "default": "Bugs Bunny",
        "action": lambda value: args.update({"name": value}),
        "description": "How to you want to be addressed?"
    }],
    install=install,
    init=init,
    run=run,
    close=close,
    dependencies={'environment_file': env_file}
)
