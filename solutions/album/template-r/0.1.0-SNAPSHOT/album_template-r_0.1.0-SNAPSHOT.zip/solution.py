from album.runner.api import setup, get_args

from io import StringIO

env_file = StringIO("""name: template-r
channels:
  - conda-forge
  - defaults
dependencies:
  - python=3.8
  - R

""")

script_file = """
args = commandArgs(trailingOnly=TRUE)
print(paste("Hi ", args[1], ", how are you?"))

"""


def install():
    print("R template :: install")


def run():
    import tempfile
    import subprocess
    print("R template :: run")

    args = get_args()

    with tempfile.NamedTemporaryFile(suffix=".r") as tmp:
        tmp.write(str.encode(script_file))
        params = ['Rscript', '--vanilla', tmp.name, args.name]
        print(" ".join(params))
        subprocess.run(params)


def close():
    print("R template :: close")


setup(
    group="album",
    name="template-r",
    version="0.1.0-SNAPSHOT",
    title="R template",
    description="An album solution template for running R code.",
    authors=["Your name"],
    cite=[{
        "text": "Your first citation text",
        "doi": "your first citation doi",
        "url": "your first citation url"
    }, {
        "text": "Your second citation text",
        "doi": "your second citation doi",
        "url": "your second citation url"
    }],
    tags=["template", "R"],
    license="UNLICENSE",
    documentation=["documentation.md"],
    covers=[{
        "description": "Dummy cover image.",
        "source": "cover.png"
    }],
    album_api_version="0.2.1",
    args=[{
        "name": "name",
        "type": "string",
        "default": "Bugs Bunny",
        "description": "How to you want to be addressed?"
    }],
    install=install,
    run=run,
    close=close,
    dependencies={'environment_file': env_file}
)
